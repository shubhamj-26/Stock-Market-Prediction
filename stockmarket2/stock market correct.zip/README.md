## Synopsis

Examples for using the Chart.js library in a Flask web application for creating line charts.

## How to Run

In the top-level folder, run the development server:
    % python app.py

Go to your favorite web browser and open:
    http://locallhost:5000

## Key Python Modules Used

- Flask - web framework
- Jinga2 - templating engine

This application is written using Python 3.4.3.

